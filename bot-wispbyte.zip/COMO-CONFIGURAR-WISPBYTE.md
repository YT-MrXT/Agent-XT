# Configurar o bot no Wispbyte

Este bot deixou de depender do Discloud (o `discloud.config` foi removido — não é preciso no Wispbyte, que não usa esse formato). O `index.js` não foi alterado.

## Passos

1. **Criar conta** em wispbyte.com (é grátis, não pede cartão de crédito).
2. **Criar servidor** → escolher a imagem Docker **Node.js**.
   - Importante: escolhe **Node 20 ou superior**. O `better-sqlite3` e o `discord.js` mais recentes já não funcionam em versões antigas do Node (confirmei nos requisitos dos pacotes).
3. **Enviar os ficheiros**: extrai o zip que te vou dar e envia `index.js`, `package.json` (e a pasta `node_modules` se já a tiveres, senão o Wispbyte instala tudo a partir do `package.json`) pelo gestor de ficheiros do painel.
4. Vai ao separador **Startup**:
   - Define o comando de arranque como `node index.js` (ou escolhe `index.js` se te pedir para selecionares o ficheiro principal).
   - Se a instalação automática das dependências falhar, podes forçar adicionando no campo **"Additional Node Packages"**: `discord.js better-sqlite3 express express-session axios node-cron`.
5. Vai à **Consola** e carrega em Start. Confirma nos logs que aparece `📦 Base de dados SQLite carregada.` e a mensagem de login do bot.

## Notas úteis

- **Conta gratuita**: precisas de entrar no painel pelo menos 1x por mês, senão o servidor é arquivado (não apagado).
- **1 bot por servidor**: no plano do Wispbyte só podes correr um bot Discord por servidor Wispbyte.
- O dashboard web (Express) continua desativado por defeito (`DASHBOARD_ATIVO`), tal como estava — não precisas de abrir nenhuma porta para o bot funcionar.
- A base de dados (`discord_bot.db`) é criada automaticamente na primeira vez que o bot corre; os dados ficam guardados no armazenamento persistente do servidor Wispbyte entre reinícios.
