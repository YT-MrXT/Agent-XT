# Bot Discord — Deploy no Render via GitHub

## ⚠️ Antes de tudo: reseta as tuas credenciais
O ficheiro original tinha o TOKEN e o CLIENT_SECRET escritos diretamente no
código. Isso já foi removido, mas se subiste esse ficheiro a algum lado
(mesmo privado), considera essas credenciais comprometidas:

1. Discord Developer Portal → a tua aplicação → **Bot** → **Reset Token**.
2. Discord Developer Portal → a tua aplicação → **OAuth2** → **Reset Secret**.
3. Usa os novos valores só nas variáveis de ambiente (nunca no código).

## 1. Subir para o GitHub
```bash
cd bot-wispbyte
git init
git add .
git commit -m "Bot Discord - pronto para Render"
git branch -M main
git remote add origin https://github.com/TEU-USUARIO/TEU-REPO.git
git push -u origin main
```
O `.gitignore` já garante que `.env`, `node_modules` e a base de dados
`.db` não vão para o GitHub.

## 2. Criar o serviço no Render
1. Vai a https://dashboard.render.com → **New** → **Web Service**.
2. Liga a tua conta GitHub e escolhe o repositório.
3. Configura:
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free (ou o que preferires)

## 3. Variáveis de ambiente no Render
Em **Environment > Environment Variables**, adiciona (valores conforme `.env.example`):

| Variável | Onde obter | Obrigatória |
|---|---|---|
| `TOKEN` | Discord Developer Portal → Bot → Reset Token | ✅ Sim |
| `CLIENT_ID` | Discord Developer Portal → General Information → Application ID | ✅ Sim |
| `CLIENT_SECRET` | Discord Developer Portal → OAuth2 → Client Secret | Só se usares o dashboard/login |
| `REDIRECT_URI` | `https://TEU-SERVICO.onrender.com/auth/callback` | Só se usares o dashboard/login |
| `SESSION_SECRET` | Qualquer string aleatória forte (ex: `openssl rand -hex 32`) | Recomendado |
| `DASHBOARD_ATIVO` | `true` ou `false` | Não (default `false`) |
| `PORT` | O Render define automaticamente — não precisas de criar | Não |

Não é preciso criar `PORT` manualmente: o Render injeta-a sozinho.

## 4. Sobre a base de dados SQLite
Este bot usa **better-sqlite3** com um ficheiro local (`discord_bot.db`).
O disco do Render é **efémero no plano Free** — o ficheiro é apagado a cada
deploy/restart. Isto significa que tickets, configs, avisos, etc. vão-se
perder sempre que o serviço reiniciar.

Se precisares que os dados persistam:
- Usa um **Render Disk** (pago, disponível em planos pagos) montado, por
  exemplo, em `/var/data`, e muda a linha no `index.js`:
  ```js
  const db = new Database('./discord_bot.db');
  ```
  para:
  ```js
  const db = new Database(process.env.DB_PATH || './discord_bot.db');
  ```
  e define `DB_PATH=/var/data/discord_bot.db` nas variáveis de ambiente.
- Ou migra para uma base de dados externa persistente (Postgres, por
  exemplo o Render Postgres gratuito), o que exigiria adaptar o código.

## 5. Free plan do Render "adormece"
No plano Free, o Render "adormece" serviços web sem tráfego HTTP após um
período de inatividade. Como este é um bot Discord (não um site visitado
por pessoas), o serviço pode ser suspenso e o bot ficar offline. Soluções
comuns:
- Fazer upgrade para um plano pago (sem sleep).
- Configurar um serviço externo (ex. UptimeRobot, cron-job.org) para fazer
  ping periódico ao endpoint HTTP do bot, mantendo-o "acordado" — só
  funciona se o Express (dashboard) estiver ativo (`DASHBOARD_ATIVO=true`),
  já que é isso que expõe uma porta HTTP para o Render monitorizar.

## 6. Correr localmente (opcional, para testar antes de subir)
```bash
cp .env.example .env
# edita o .env com os teus valores
npm install
npm start
```
